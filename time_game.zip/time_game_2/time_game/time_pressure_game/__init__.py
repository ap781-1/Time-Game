from otree.api import *
from datetime import datetime

doc = """
Your app description
"""

# Models
class Constants(BaseConstants):
    name_in_url = 'time_game'
    players_per_group = None
    num_rounds = 1
    TOTAL_TIME = 100


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    age = models.IntegerField(label='Your age:', min=18, max=100, blank=True)
    gender = models.CharField(
        label='Your gender:',
        choices=['Male', 'Female', 'Other'],
        widget=widgets.RadioSelect)
    education = models.CharField(
        label='Your education:',
        choices=['High School', 'College', 'Graduate'],
        widget=widgets.RadioSelect)
    player_id = models.IntegerField(label='Player Id')
    entry_time = models.IntegerField()
    total_time_spent = models.IntegerField()  # Store time in seconds
    time_spent_last_page = models.IntegerField(initial=0) # in seconds 

    G1Question1 = models.IntegerField(
        label='What makes the bookstore "Words & Whims" special?',
        choices=[
        [0, 'Its modern design and sleek architecture'],
        [0, 'The collection of rare plants it houses.'],
        [1, 'The mysterious proprietor and its magical secret.'],
        [0, 'Its focus on contemporary bestsellers.'],
        ],
        widget=widgets.RadioSelect)
    G1Question2 = models.IntegerField(
        label=' What is Elias Hawthorne`s role in the bookstore and the world of literature?',
        choices=[
        [0, 'He is a storyteller, writing his own novels.'],
        [1, 'He is a guardian of the portal to another world.'],
        [0, 'He is a renowned literary critic.'],
        [0, 'He is an illusionist who creates the magical ambiance.'],
        ],
        widget=widgets.RadioSelect)
    G1Question3 = models.IntegerField(
        label='What happens to the books in the bookstore at night?',
        choices=[
        [0, 'They are rearranged for aesthetic purposes.'],
        [0, 'They come alive and interact with each other.'],
        [1, 'They transform into portals to other worlds.'],
        [0, 'They emit a soothing aroma that lulls visitors to sleep.'],
        ],
        widget=widgets.RadioSelect)
    G1Question4 = models.IntegerField(
        label='What qualities must potential apprentices possess?',
        choices=[
        [0, 'A dislike for reading and a love for adventure.'],
        [1, 'A deep love for literature and an adventurous spirit.'],
        [0, 'A strong dislike for books and a skeptical nature.'],
        [0, 'A passion for technology and modern trends.'],
        ],
        widget=widgets.RadioSelect)
    G1Question5 = models.IntegerField(
        label='What is the primary function of "PsyNex" technology in this society? ',
        choices=[
        [1, 'Enabling direct mind-to-mind communication '],
        [0, 'Generating unlimited energy '],
        [0, 'Predicting future events'],
        [0, 'Enhancing physical strength '],
        ],
        widget=widgets.RadioSelect)
    G1Question6 = models.IntegerField(
        label='What role does the hacker group play in the story?',
        choices=[
        [0, 'They develop PsyNex technology'],
        [0, 'They enhance individuals` physical abilities'],
        [0, 'They advocate for the banning of PsyNex'],
        [1, 'They manipulate people`s thoughts and emotions through PsyNex '],
        ],
        widget=widgets.RadioSelect)
    G1Question7 = models.IntegerField(
        label='How do the individuals with unique PsyNex abilities contribute to the resolution of the conflict?',
        choices=[
        [1, 'They use their abilities to locate and neutralize the hackers'],
        [0, 'They disconnect from PsyNex to escape the chaos'],
        [0, 'They work with the hackers to create chaos'],
        [0, 'They attempt to destroy PsyNex technology entirely'],
        ],
        widget=widgets.RadioSelect)
    G1Question8 = models.IntegerField(
        label='What potential danger arises from the hacker group`s manipulation of thoughts and emotions through \
        PsyNex?',
        choices=[
        [0, 'Enhanced problem-solving abilities'],
        [0, 'Improved mental health for individuals '],
        [1, 'Global chaos and loss of control over society'],
        [0, 'Enhanced empathy and understanding among people'],
        ],
        widget=widgets.RadioSelect)
    G1Question9 = models.IntegerField(
        label='Peter can type 40 letters in 10 minutes. Jack can type 80 letters in 10 minutes. How many letters will \
        the two of them type in 2 hours?',
        choices=[
            [1, '1440'],
            [0, '1240'],
            [0, '480'],
            [0, '1360'],
            ],
        widget=widgets.RadioSelect)
    G1Question10 = models.IntegerField(
        label='45 is what percent of 900??',
        choices=[
            [0, '4%'],
            [1, '5%'],
            [0, '9%'],
            [0, '7%'],
        ],
        widget=widgets.RadioSelect)
    G1Question11 = models.IntegerField(
        label='What is the remainder when 499 is divided by 11??',
        choices=[
            [0, '5'],
            [1, '4'],
            [0, '3'],
            [0, '0'],
        ],
        widget=widgets.RadioSelect)
    G1Question12 = models.IntegerField(
        label='The football club has 18 members. If each member brings 12 pairs of shoes, how many pair of shoes will \
        the entire club bring?',
        choices=[
            [0, '108'],
            [0, '206'],
            [1, '216'],
            [0, '246'],
        ],
        widget=widgets.RadioSelect)
    G1Question13 = models.IntegerField(
        label='The sum of the ages of 3 people: Peter, Jack and Amy is 75 years old. What would be the sum of their ages \
        6 years back?',
        choices=[
            [1, '57'],
            [0, '60'],
            [0, '67'],
            [0, '69'],
        ],
        widget=widgets.RadioSelect)
    G1Question14 = models.IntegerField(
        label='Peter and Jack decided to play badminton against each other. They bet $1 on each game they played. \
        Peter won 5 games and Jack won $3. How many games did they play?',
        choices=[
            [0, '5'],
            [0, '8'],
            [0, '10'],
            [1, '13'],
        ],
        widget=widgets.RadioSelect)
    G2Question1 = models.IntegerField(
        label='How do government agents respond to the activities of the "Clockbreakers"?',
        choices=[
            [0, 'They support and assist the Clockbreakers` mission'],
            [0, 'They ignore the Clockbreakers` actions'],
            [1, 'They actively pursue and try to stop the Clockbreakers'],
            [0, 'They join the Clockbreakers in their quest'],
        ],
        widget=widgets.RadioSelect)
    G2Question2 = models.IntegerField(
        label='What is the primary goal of the "Clockbreakers" group?',
        choices=[
            [0, 'To overthrow the government '],
            [0, 'To discover ancient texts '],
            [1, 'To find the secret to unlimited lifetimes'],
            [0, 'To expose government secrets'],
        ],
        widget=widgets.RadioSelect)
    G2Question3 = models.IntegerField(
        label='What is the norm in this society regarding individuals` life spans?',
        choices=[
            [0, 'Every individual has an unlimited life span'],
            [1, 'Life spans are measured and guaranteed by a government agency'],
            [0, 'Life spans are determined by genetic factors'],
            [0, 'Life spans are completely random and unpredictable'],
        ],
        widget=widgets.RadioSelect)
    G2Question4 = models.IntegerField(
        label='What motivates the "Clockbreakers" to challenge the established order?',
        choices=[
            [0, 'They seek power and control over society'],
            [1, 'They believe that limited life spans are unnatural '],
            [0, 'They aim to become government agents themselves'],
            [0, 'They want to prove the existence of Eternal Haven'],
        ],
        widget=widgets.RadioSelect)
    G2Question5 = models.IntegerField(
        label='What is the main attraction of the "DreamScape" VR theme park?',
        choices=[
            [1, 'Fulfilling visitors` dreams and fantasies'],
            [0, 'A roller coaster with high-speed twists'],
            [0, 'Hyper-realistic simulations of everyday life '],
            [0, 'A space adventure exploring distant galaxies'],
        ],
        widget=widgets.RadioSelect)
    G2Question6 = models.IntegerField(
        label='What issue arises as people spend more time in DreamScape? ',
        choices=[
            [0, 'They become less interested in virtual reality experiences'],
            [1, 'The lines between reality and the virtual world become blurred'],
            [0, 'They begin to prefer traditional amusement parks '],
            [0, 'The technology used in DreamScape becomes outdated'],
        ],
        widget=widgets.RadioSelect)
    G2Question7 = models.IntegerField(
        label='What might be a potential consequence of the glitches and crossovers between the virtual and real worlds\
             in DreamScape? ',
        choices=[
            [0, 'Increased revenue for the theme park'],
            [1, 'Enhanced safety measures for visitors'],
            [1, 'Ethical concerns and psychological impacts on users'],
            [0, 'More diverse entertainment options for visitors'],
        ],
        widget=widgets.RadioSelect)
    G2Question8 = models.IntegerField(
        label='How do the blurring boundaries between the virtual world and reality affect visitors?',
        choices=[
            [0, 'Visitors become more disinterested in their own lives'],
            [0, 'Visitors develop superhuman abilities'],
            [0, 'Visitors experience improved mental well-being'],
            [1, 'Visitors start to doubt the existence of the real world'],
        ],
        widget=widgets.RadioSelect)
    G2Question9 = models.IntegerField(
        label='Martha can file 50 letters in 10 minutes. David can file 40 letters in the same amount of time. \
            How many letters will the two of them file in 3 hours??',
        choices=[
            [0, '1520'],
            [1, '1620'],
            [0, '1660'],
            [0, '2700'],
        ],
        widget=widgets.RadioSelect)
    G2Question10 = models.IntegerField(
        label='65 is what percent of 500?',
        choices=[
            [0, '8'],
            [0, '11'],
            [1, '13'],
            [0, '17'],
        ],
        widget=widgets.RadioSelect)
    G2Question11 = models.IntegerField(
        label='What is the remainder when 599 is divided by 9??',
        choices=[
            [1, '5'],
            [0, '6'],
            [0, '9'],
            [0, '0'],
        ],
        widget=widgets.RadioSelect)
    G2Question12 = models.IntegerField(
        label='A club has 36 members. If each member donates 12 items for an auction, how many items will there be \
        in the auction?',
        choices=[
            [0, '48'],
            [0, '108'],
            [0, '422'],
            [1, '432'],
        ],
        widget=widgets.RadioSelect)
    G2Question13 = models.IntegerField(
        label='The sum of the ages of 3 people: Martha, David and Daniel is 90 years old. \
        What would be the sum of their ages 4 years back?',
        choices=[
            [0, '68'],
            [0, '76'],
            [1, '78'],
            [0, '82'],
        ],
        widget=widgets.RadioSelect)
    G2Question14 = models.IntegerField(
        label='Susan and Lisa decided to play tennis against each other. They bet $1 on each game they played. \
        Susan won three bets and Lisa won $5. How many games did they play?',
        choices=[
            [0, '5'],
            [0, '8'],
            [0, '9'],
            [1, '11'],
        ],
        widget=widgets.RadioSelect)

    score1 = models.FloatField(initial=0)
    score2 = models.FloatField(initial=0)

# utils
def calculate_time_spent(player: Player):
    exit_time = int(datetime.now().timestamp()) # convert float to int 
    time_difference = exit_time - player.entry_time 
    player.time_spent_last_page = time_difference
    if player.field_maybe_none('total_time_spent') is not None:
        player.total_time_spent = player.field_maybe_none('total_time_spent') + player.time_spent_last_page
    else:
        player.total_time_spent = player.time_spent_last_page
    # reset entry time
    player.entry_time = int(datetime.now().timestamp())

def add_weights_to_questions(player: Player, TOTAL_TIME = 600, question_id = []):
    # correct answer * 600/time-taken

    time_taken = player.total_time_spent # on game 2

    for i in question_id:
        payoff_per_question = i * (TOTAL_TIME/time_taken)
        player.score2 += payoff_per_question
        if player.score2 >= 20:
            player.score2 = 20

    
    player.payoff += player.score2


# PAGES
class Rules(Page):
    pass

class Introduction(Page):
    form_model = 'player'
    form_fields = ['age', 'gender', 'education']


# Game 1 
class G1Page1(Page):
    timeout_seconds = 90
    
    form_model = 'player'
    form_fields = ['G1Question1', 'G1Question2', 'G1Question3','G1Question4']


class G1Page2(Page):
    timeout_seconds = 90
    
    form_model = 'player'
    form_fields = ['G1Question5', 'G1Question6','G1Question7', 'G1Question8']


class G1Page3(Page):
    timeout_seconds = 90
    
    form_model = 'player'
    form_fields = ['G1Question9', 'G1Question10','G1Question11']


class G1Page4(Page):
    timeout_seconds = 90
        
    form_model = 'player'
    form_fields = ['G1Question12', 'G1Question13', 'G1Question14']

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
          player.score1 += player.G1Question1 + player.G1Question2 + player.G1Question3 + player.G1Question4 + player.G1Question5 +\
                       player.G1Question6 + player.G1Question7 + player.G1Question8 + player.G1Question9 + player.G1Question10 +\
                       player.G1Question11+ player.G1Question12 + player.G1Question13 + player.G1Question14
          player.payoff += player.score1
          player.total_time_spent  = 0

# Break page 
class Break(Page):
    timeout_seconds = 30
    
# Game 2 
class Instruction1(Page):
    @staticmethod
    def before_next_page(player, timeout_happened):
        player.entry_time =  int(datetime.now().timestamp()) # record time for game 2

class G2Page1(Page):
    form_model = 'player'
    form_fields = ['G2Question1', 'G2Question2', 'G2Question3', 'G2Question4']

class G2Page2(Page):
    form_model = 'player'
    form_fields = ['G2Question5', 'G2Question6', 'G2Question7', 'G2Question8']

class G2Page3(Page):
    form_model = 'player'
    form_fields = ['G2Question9', 'G2Question10', 'G2Question11']

class G2Page4(Page):
        form_model = 'player'
        form_fields = ['G2Question12', 'G2Question13', 'G2Question14']

        @staticmethod
        def before_next_page(player: Player, timeout_happened):
            # first do computation to calculate total time since game 2 started 
            # we started tracking in Introduction1 page 
            calculate_time_spent(player)

            # compute payoffs
            add_weights_to_questions(player, 600,
                                     [
                                        player.G2Question1, player.G2Question2, player.G2Question3,
                                        player.G2Question4, player.G2Question5, player.G2Question6,
                                        player.G2Question7, player.G2Question8, player.G2Question9,
                                        player.G2Question10, player.G2Question11, player.G2Question12,
                                        player.G2Question13, player.G2Question14])
    
# Results
class Results(Page):
    @staticmethod
    def vars_for_template(player: Player):
        return dict (
            score_game_1= player.score1,
            score_game_2= player.score2,
            payoff= player.payoff,
            total_time_spent= player.total_time_spent
        )


page_sequence = [Rules, Introduction, G1Page1, G1Page2, G1Page3, G1Page4,Break,Instruction1, G2Page1, G2Page2, G2Page3, G2Page4, Results]
